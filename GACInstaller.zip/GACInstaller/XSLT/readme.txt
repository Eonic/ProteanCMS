﻿VDProj to WiX Converter
----------------------------------------------------------------------------------------------

CONTENT OF THE XSLT FOLDER
----------------------------------------------------------------------------------------------
1. RegisterForCOM.xml: Contains XML for files that should be registered for COM.
2. XslRegisterForCOM.xslt: Contains XSL to apply to the RegisterForCOM.xml file.
3. XslProjectOutput.xslt: Contains XSL to apply to the generated XML for referenced projects.
4. XslFile.xslt: Contains XSL to apply to the generated XML for the COM files listed in 
   the RegisterForCOM.xml file.
5. *.xml files: XML files that describe the referenced projects.
